// imgsnag — Content Script

(function () {
  'use strict';

  // Constants

  const IMAGE_EXT_RE = /\.(?:jpe?g|gif|png|webp|svg|avif)(?:[?#]|$)/i;
  const VIDEO_EXT_RE = /\.(?:mp4|webm|ogv|mov|m4v|avi)(?:[?#]|$)/i;
  const BG_URL_RE = /url\(["']?(.*?)["']?\)/gi;
  // RFC #223 stage 1: cheap gate before any URL construction, then the strict
  // CMS "-WxH" variant suffix it synthesizes an original from.
  const WP_SUFFIX_FAST_RE = /-\d+x\d+\./;
  const WP_SUFFIX_RE = /-\d+x\d+(\.(?:jpe?g|png|webp|gif|avif))$/i;

  // RFC #223 stage 2: CDNs serve scaled variants via sizing query params, so the
  // stripped URL is often the original. Gated by a fast regex so the URL parse
  // only happens for URLs that actually carry one.
  const QUERY_SIZE_FAST_RE = /[?&](?:w|h|width|height)=\d+/i;
  const SIZE_QUERY_PARAMS = ['w', 'h', 'width', 'height'];

  // Catches image URLs embedded in inline scripts or JSON-LD that DOM queries miss
  const IMAGE_URL_RE =
    /https?:(?:\\?\/){2}[^\s"'<>]+\.(?:jpe?g|gif|png|webp|svg|avif)(?:\?[^\s"'<>]*)?/gi;

  // Cheap pre-check before the expensive URL sweep. Case-insensitive because
  // IMAGE_URL_RE is: a literal includes('http') check would miss "HtTp://".
  const HTTP_HINT_RE = /http/i;

  // Stateless, so the initial sweep and the MutationObserver share one instance
  // rather than rebuilding it per added subtree. <style> never holds image URLs
  // the CSS scan misses; <script> is only worth sweeping when it carries JSON.
  const REGEX_SWEEP_FILTER = {
    acceptNode(node) {
      if (node.nodeType === Node.ELEMENT_NODE) {
        if (node.tagName === 'STYLE') return NodeFilter.FILTER_REJECT;
        if (node.tagName === 'SCRIPT') {
          const type = node.getAttribute('type');
          if (type === 'application/ld+json' || type === 'application/json') {
            return NodeFilter.FILTER_ACCEPT;
          }
          return NodeFilter.FILTER_REJECT;
        }
        if (!node.hasAttributes()) return NodeFilter.FILTER_SKIP;
      }
      return NodeFilter.FILTER_ACCEPT;
    }
  };

  const BG_IMAGE_SELECTORS =
    'div, span, section, article, header, footer, a, li, figure, i, button, main, dialog, [style*="background"], [style*="mask"]';

  const MIN_IMAGE_SIZE = 200;
  // Ceiling on simultaneous `new Image()` size probes. Each in-flight probe holds
  // a decoded bitmap, so an unbounded fan-out over a large gallery is a memory
  // spike, not just extra requests.
  const SIZE_PROBE_POOL_SIZE = 12;
  // Lazy-load attribute families. Hoisted because handleVideo/handleSource run
  // once per added node on the MutationObserver path, and a fresh array literal
  // per node is pure garbage. These are read as a *list*, not a preference
  // order: every populated attribute is tracked, because a placeholder `src`
  // sitting next to the real `data-src` is the whole lazy-load pattern.
  const MEDIA_SRC_ATTRS = ['src', 'data-src', 'data-lazy-src', 'data-original'];
  const POSTER_ATTRS = ['poster', 'data-poster'];
  // Same story on <picture><source>, split by parse shape: the first two hold a
  // srcset candidate list, the rest a bare URL.
  const SOURCE_SRCSET_ATTRS = ['srcset', 'data-srcset'];
  const SOURCE_URL_ATTRS = ['src', 'data-src', 'data-lazy-src', 'data-original'];
  const DATA_BG_ATTRS = ['data-bg', 'data-bg-src', 'data-background', 'data-background-image'];
  // Tags worth an attribute sweep when they turn up in a MutationObserver batch
  const TAG_SET = new Set(['IMG', 'VIDEO', 'SOURCE', 'PICTURE', 'DIV', 'SPAN', 'SECTION', 'ARTICLE', 'HEADER', 'FOOTER', 'A', 'AREA', 'LI', 'FIGURE', 'I', 'META', 'LINK', 'OBJECT', 'EMBED', 'IFRAME', 'image', 'IMAGE', 'INPUT', 'BUTTON', 'MAIN', 'DIALOG']);

  // <input type="image"> renders and resolves its src exactly like an <img>, so every
  // path that reads an <img> treats it the same way. `el.type` is the IDL attribute,
  // which is already lowercased and defaults to 'text' when absent.
  function isImgLike(el) {
    return el.tagName === 'IMG' || (el.tagName === 'INPUT' && el.type === 'image');
  }
  // The static-scan counterpart of isImgLike. `type` is one of the attributes HTML
  // matches ASCII case-insensitively in selectors, so type="IMAGE" matches too.
  const IMG_LIKE_SELECTOR = ['img', 'input[type="image"]']
    .flatMap((base) => SOURCE_URL_ATTRS.map((attr) => `${base}[${attr}]`))
    .join(', ');

  // Inline-SVG capture (derived files, RFC #118 stage 1)
  const SVG_DATA_PREFIX = 'data:image/svg+xml;charset=utf-8,';
  const MAX_INLINE_SVG_CHARS = 2 * 1024 * 1024;
  // Ceiling on the per-document media stores. These deliberately outlive DOM
  // nodes (infinite scroll recycles them), so nothing else bounds their growth.
  // Not an amplification defence — a page must spend more memory building the
  // URLs than we spend holding them — but a content script on <all_urls> should
  // not grow without limit on a page that scrolls forever. 10k is far above any
  // real gallery and caps each store around 2MB per tab.
  const MAX_TRACKED_MEDIA = 10000;

  // Persistent media store — survives DOM removal (infinite scroll recycling)
  const discoveredMedia = new Map();
  let popupPort = null;
  let isDragDisabled = false;

  // Background image lazy evaluation queue (Feather: getComputedStyle batched at idle)
  const pendingBackgroundCheckQueue = new Set();
  let isBgCheckScheduled = false;

  // Helpers

  function sendToBackground(message) {
    browser.runtime.sendMessage(message).catch(() => {});
  }


  function trackImageUrl(raw, urlSet) {
    const url = resolveUrl(raw);
    if (!url || url.startsWith('data:')) return;
    urlSet.add(url);
    if (WP_SUFFIX_FAST_RE.test(url)) {
      try {
        const parsed = new URL(url);
        if (WP_SUFFIX_RE.test(parsed.pathname)) {
          parsed.pathname = parsed.pathname.replace(WP_SUFFIX_RE, '$1');
          const synth = resolveUrl(parsed.href);
          if (synth && !synth.startsWith('data:')) urlSet.add(synth);
        }
      } catch {}
    }
    if (QUERY_SIZE_FAST_RE.test(url)) {
      try {
        const parsed = new URL(url);
        // SVGs are exempt from the size filter, so a synthesized SVG URL would
        // be admitted without ever being verified — a wrong guess would reach
        // the popup as a broken item. Every other type gets culled by the
        // network probe when the guess does not resolve, so only SVG is unsafe
        // to guess at.
        if (!parsed.pathname.toLowerCase().endsWith('.svg')) {
          let stripped = false;
          for (const param of SIZE_QUERY_PARAMS) {
            if (parsed.searchParams.has(param)) {
              parsed.searchParams.delete(param);
              stripped = true;
            }
          }
          if (stripped) {
            const synth = resolveUrl(parsed.href);
            if (synth && !synth.startsWith('data:')) urlSet.add(synth);
          }
        }
      } catch {}
    }
  }

  function resolveUrl(url) {
    if (!url) return null;
    try {
      const parsed = new URL(url, document.baseURI);
      // Warden: Restrict to safe protocols to prevent exfiltration / local file access
      const p = parsed.protocol;
      if (p !== 'http:' && p !== 'https:' && p !== 'blob:' && p !== 'data:') {
        return null;
      }
      return parsed.href;
    } catch {
      return null;
    }
  }

  function isImageUrl(url) {
    if (!url) return false;
    if (url.startsWith('data:image/')) return true;
    try {
      return IMAGE_EXT_RE.test(new URL(url).pathname);
    } catch {
      return false;
    }
  }

  function isVideoUrl(url) {
    if (!url) return false;
    try {
      return VIDEO_EXT_RE.test(new URL(url).pathname);
    } catch {
      return false;
    }
  }

  function isSvgUrl(url) {
    try {
      return /\.svg(?:[?#]|$)/i.test(new URL(url).pathname);
    } catch {
      return false;
    }
  }

  function extractBgImageUrls(bgValue) {
    const urls = [];

    const urlKeyword = 'url(';
    let urlIdx = 0;
    const lowerBg = bgValue.toLowerCase();
    while ((urlIdx = lowerBg.indexOf(urlKeyword, urlIdx)) !== -1) {
      const start = urlIdx + urlKeyword.length;
      let depth = 1;
      let i = start;
      for (; i < bgValue.length; i++) {
        if (bgValue[i] === '(') depth++;
        else if (bgValue[i] === ')') depth--;
        if (depth === 0) break;
      }
      if (depth === 0) {
        let inner = bgValue.substring(start, i).trim();
        if ((inner.startsWith('"') && inner.endsWith('"')) || (inner.startsWith("'") && inner.endsWith("'"))) {
          inner = inner.substring(1, inner.length - 1);
        }
        if (inner) urls.push(inner);
      }
      urlIdx = i + 1;
    }

    const keyword = 'image-set(';
    let idx = 0;
    while ((idx = lowerBg.indexOf(keyword, idx)) !== -1) {
      const start = idx + keyword.length;
      let depth = 1;
      let i = start;
      for (; i < bgValue.length; i++) {
        if (bgValue[i] === '(') depth++;
        else if (bgValue[i] === ')') depth--;
        if (depth === 0) break;
      }
      const inner = bgValue.substring(start, i);
      // url() variants are already collected by BG_URL_RE above; type() carries a
      // MIME string, not a URL — strip both before harvesting bare-string variants.
      const withoutUrls = inner.replace(/(?:url|type)\([^)]*\)/gi, '');
      const QUOTE_RE = /(["'])(.*?)\1/g;
      let quoteMatch;
      while ((quoteMatch = QUOTE_RE.exec(withoutUrls)) !== null) {
        if (quoteMatch[2].trim()) urls.push(quoteMatch[2]);
      }
      idx = i + 1;
    }
    return urls;
  }

  function getCssMediaUrls(el, useDisplayAccurate = false) {
    const urls = [];
    try {
      const rawStyle = el.getAttribute('style') || '';
      const hasExternalStyling = el.hasAttribute('class') || el.id;
      const hasInlineMaskOrContent = rawStyle.includes('mask') || rawStyle.includes('content');

      const canSkipComputed = !useDisplayAccurate && !hasExternalStyling && !hasInlineMaskOrContent;

      const styles = [];
      if (canSkipComputed) {
        styles.push(el.style);
      } else {
        styles.push(getComputedStyle(el));
        try { styles.push(getComputedStyle(el, '::before')); } catch {}
        try { styles.push(getComputedStyle(el, '::after')); } catch {}
      }

      let isMainElement = true;
      for (const style of styles) {
        if (!style) continue;

        let bgImage = style.backgroundImage;
        if (isMainElement && !useDisplayAccurate && !canSkipComputed && el.style && el.style.backgroundImage) {
          const inlineBg = el.style.backgroundImage;
          if (inlineBg && inlineBg !== 'none' && inlineBg !== 'normal') {
             bgImage = inlineBg;
          }
        }

        const props = [
          bgImage,
          style.maskImage || style.getPropertyValue('mask-image'),
          style.webkitMaskImage || style.getPropertyValue('-webkit-mask-image'),
          style.content
        ];
        for (const bg of props) {
          if (bg && bg !== 'none' && bg !== 'normal') {
            for (const raw of extractBgImageUrls(bg)) {
              if (!urls.includes(raw)) urls.push(raw);
            }
          }
        }
        isMainElement = false;
      }
    } catch {
      // Element may not be connected to DOM yet
    }
    return urls;
  }

  function parseSrcset(srcset) {
    if (!srcset) return [];
    return srcset
      .split(',')
      .map((entry) => entry.trim().split(/\s+/)[0])
      .filter(Boolean);
  }

  // A srcset lists the SAME image at several sizes/densities. Tracking every
  // candidate floods the grid with duplicates (one cell per width variant),
  // so pick the single best candidate: highest w or x descriptor.
  function pickBestFromSrcset(srcset) {
    if (!srcset) return null;
    let bestUrl = null;
    let bestScore = -1;

    let pos = 0;
    while (pos < srcset.length) {
      while (pos < srcset.length && /\s/.test(srcset[pos])) pos++;
      if (pos >= srcset.length) break;

      let url = "";
      while (pos < srcset.length && !/\s/.test(srcset[pos])) {
        url += srcset[pos];
        pos++;
      }

      let descriptor = "";
      if (url.endsWith(',')) {
        url = url.slice(0, -1);
      } else {
        while (pos < srcset.length && /\s/.test(srcset[pos])) pos++;
        while (pos < srcset.length && srcset[pos] !== ',') {
          descriptor += srcset[pos];
          pos++;
        }
        if (pos < srcset.length && srcset[pos] === ',') pos++;
      }

      if (!url) continue;

      let score = 1;
      descriptor = descriptor.trim();
      if (descriptor) {
        const parts = descriptor.split(/\s+/);
        for (const d of parts) {
          const n = parseFloat(d);
          if (!Number.isNaN(n)) score = /w$/i.test(d) ? n : n * 1000;
        }
      }

      if (score > bestScore) {
        bestScore = score;
        bestUrl = url;
      }
    }
    return bestUrl;
  }

  // Every populated variant on one <picture><source>, handed to `track`.
  //
  // Read as a *list*, not a preference order — same reasoning as MEDIA_SRC_ATTRS.
  // Lazy-load markup routinely pairs a placeholder `srcset`/`src` with the real
  // `data-srcset`/`data-src`, and a `||` chain that stopped at the first hit took
  // the placeholder and dropped the full-resolution variant entirely. Tracking
  // both is safe here because these land in the image set, where the ≥200x200
  // filter culls whichever one was the placeholder. (That cull is real for
  // images; it is NOT available for videos, which skip the size filter.)
  //
  // Returns whether this source yielded a *real* URL. "Real" is deliberately the
  // same condition trackImageUrl accepts on (resolves, and not an inline data:
  // payload), so a source counts as "usable" exactly when it actually put
  // something in the set. Only a usable source ends the caller's scan of its
  // siblings — one carrying nothing but an inline LQIP placeholder tracked
  // nothing, so it must not shadow the next source.
  function collectSourceVariants(source, track) {
    let usable = false;
    for (const attr of SOURCE_SRCSET_ATTRS) {
      const best = pickBestFromSrcset(source.getAttribute(attr));
      if (best) {
        track(best);
        usable = usable || isRealMediaUrl(best);
      }
    }
    for (const attr of SOURCE_URL_ATTRS) {
      const val = source.getAttribute(attr);
      if (val) {
        track(val);
        usable = usable || isRealMediaUrl(val);
      }
    }
    return usable;
  }

  function isRealMediaUrl(raw) {
    const url = resolveUrl(raw);
    return !!url && !url.startsWith('data:');
  }

  // Media discovery — scans the DOM for downloadable image and video URLs

  function collectImages(trackImage) {
    // <meta> Open Graph / Twitter, <link rel="preload"> hints, and icons
    document.querySelectorAll('meta[property="og:image"], meta[property="og:image:secure_url"], meta[name="twitter:image"], meta[name="twitter:image:src"], meta[itemprop="image"], link[rel="preload"][as="image"], link[rel="icon"], link[rel="apple-touch-icon"], link[rel="shortcut icon"], link[rel="image_src"], link[rel="mask-icon"], link[itemprop="image"]').forEach((el) => {
      // A responsive preload's `href` is only the fallback for browsers that
      // ignore imagesrcset. The [imagesrcset] sweep below already takes the best
      // candidate, so emitting href here too would double-count one image —
      // but only when that candidate is real; a data: LQIP tracks nothing and
      // must not suppress the fallback.
      if (el.tagName === 'LINK' && el.getAttribute('rel') === 'preload' && el.getAttribute('as') === 'image') {
        if (isRealMediaUrl(pickBestFromSrcset(el.getAttribute('imagesrcset')))) return;
      }
      const url = el.getAttribute('content') || el.getAttribute('href');
      if (url) trackImage(url);
    });

    // <img src> and lazy loaded variants. When the element carries a srcset
    // (or data-srcset), src is just one more variant of the same image — the
    // srcset best-pick below covers it, so skip src to avoid duplicates. But a
    // srcset of nothing but data: LQIP placeholders tracks nothing, so it must
    // not suppress the src fallback (same rule as the imagesrcset preload above).
    // Inside a <picture>, the per-picture sweep below already elects one
    // variant — src there is a duplicate under a different URL, so it stays out.
    document.querySelectorAll(IMG_LIKE_SELECTOR).forEach((img) => {
      const inPicture = img.parentElement?.tagName === 'PICTURE';
      const hasSet = img.hasAttribute('srcset') || img.hasAttribute('data-srcset');

      let setUsable = false;
      if (inPicture) {
        const pic = img.parentElement;
        for (const source of pic.querySelectorAll('source')) {
          let sourceUsable = false;
          for (const attr of SOURCE_SRCSET_ATTRS) {
            const best = pickBestFromSrcset(source.getAttribute(attr));
            if (best && isRealMediaUrl(best)) { sourceUsable = true; break; }
          }
          if (!sourceUsable) {
            for (const attr of SOURCE_URL_ATTRS) {
              const val = source.getAttribute(attr);
              if (val && isRealMediaUrl(val)) { sourceUsable = true; break; }
            }
          }
          if (sourceUsable) { setUsable = true; break; }
        }
      }

      if (!setUsable && hasSet) {
        for (const attr of SOURCE_SRCSET_ATTRS) {
          const val = pickBestFromSrcset(img.getAttribute(attr));
          if (val && isRealMediaUrl(val)) {
            setUsable = true;
            break;
          }
        }
      }

      if (img.src && !setUsable) trackImage(img.src);
      if (img.hasAttribute('data-src')) trackImage(img.getAttribute('data-src'));
      if (img.hasAttribute('data-lazy-src')) trackImage(img.getAttribute('data-lazy-src'));
      if (img.hasAttribute('data-original')) trackImage(img.getAttribute('data-original'));
    });

    // srcset attributes (img, source, etc.) — best candidate only.
    // <picture> sources are handled per-picture below (format alternatives).
    document.querySelectorAll('[srcset], [data-srcset], [data-bgset], [imagesrcset]').forEach((el) => {
      if (el.tagName === 'SOURCE' && el.parentElement?.tagName === 'PICTURE') return;
      const attrs = ['srcset', 'data-srcset', 'data-bgset', 'imagesrcset'];
      for (const attr of attrs) {
        const best = pickBestFromSrcset(el.getAttribute(attr));
        if (best) trackImage(best);
      }
    });

    document.querySelectorAll('[data-bg], [data-bg-src], [data-background], [data-background-image]').forEach((el) => {
      for (const attr of DATA_BG_ATTRS) {
        if (el.hasAttribute(attr)) {
          const bg = el.getAttribute(attr);
          if (bg) {
            if (bg.includes('url(') || bg.includes('image-set(')) {
              for (const raw of extractBgImageUrls(bg)) trackImage(raw);
            } else {
              const url = resolveUrl(bg.trim());
              if (isImageUrl(url)) trackImage(bg.trim());
            }
          }
        }
      }
    });

    // <picture>: every <source> is the SAME image in another format/breakpoint.
    // Prefer the variant the browser actually rendered; otherwise take the
    // candidates of the first usable source (see collectSourceVariants).
    document.querySelectorAll('picture').forEach((pic) => {
      const img = pic.querySelector('img');
      if (img && img.currentSrc) {
        const url = resolveUrl(img.currentSrc);
        if (url && !url.startsWith('data:')) {
          trackImage(img.currentSrc);
          return;
        }
      }
      for (const source of pic.querySelectorAll('source')) {
        if (collectSourceVariants(source, trackImage)) return;
      }
    });

    // <video poster> and lazy loaded variants (still an image)
    document.querySelectorAll('video[poster], video[data-poster]').forEach((video) => {
      POSTER_ATTRS.forEach(attr => {
        const val = video.getAttribute(attr);
        if (val) trackImage(val);
      });
    });

    // <object>/<embed>/<iframe> whose source is an image file
    document.querySelectorAll('object[data], embed[src], iframe[src]').forEach((el) => {
      const raw = el.tagName === 'OBJECT' ? el.getAttribute('data') : el.getAttribute('src');
      if (isImageUrl(resolveUrl(raw))) trackImage(raw);
    });

    // <svg image> embedded images
    document.querySelectorAll('svg image, image').forEach((el) => {
      const raw = el.getAttribute('href') || el.getAttribute('xlink:href');
      if (raw) trackImage(raw);
    });

    // <a> and <area> links pointing directly to images (e.g. lightbox links)
    document.querySelectorAll('a[href], area[href]').forEach((el) => {
      const raw = el.getAttribute('href');
      if (raw && isImageUrl(resolveUrl(raw))) trackImage(raw);
    });

    // CSS background-image on likely container elements
    document.querySelectorAll(BG_IMAGE_SELECTORS).forEach((el) => {
      // Fast path: skip elements with no styling hints to avoid expensive getComputedStyle calls
      if (!el.hasAttribute('class') && !el.id && !el.getAttribute('style')) return;

      pendingBackgroundCheckQueue.add(el);
      if (!isBgCheckScheduled) {
        isBgCheckScheduled = true;
        if (typeof requestIdleCallback !== 'undefined') {
          requestIdleCallback(processBgImageQueue);
        } else {
          setTimeout(processBgImageQueue, 1);
        }
      }
    });

    // Fallback — scan text and attributes to catch JSON-LD or data attributes that DOM queries miss
    const walker = document.createTreeWalker(
      document.documentElement,
      NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT,
      REGEX_SWEEP_FILTER
    );

    let node;
    while ((node = walker.nextNode())) {
      extractRegexUrls(node, trackImage);
    }
  }

  // Shared by the initial sweep and the MutationObserver: pulls image URLs out
  // of a single node's text content or attribute values.
  function extractRegexUrls(node, trackImage) {
    if (node.nodeType === Node.TEXT_NODE) {
      const parent = node.parentElement;
      if (parent) {
        const tag = parent.tagName;
        if (tag === 'STYLE' || (tag === 'SCRIPT' && parent.type !== 'application/ld+json' && parent.type !== 'application/json')) {
          return;
        }
      }
      if (node.nodeValue && HTTP_HINT_RE.test(node.nodeValue)) {
        let match;
        IMAGE_URL_RE.lastIndex = 0;
        while ((match = IMAGE_URL_RE.exec(node.nodeValue)) !== null) {
          let url = match[0];
          if (url.includes('\\')) url = url.replace(/\\/g, '');
          trackImage(url);
        }
      }
    } else if (node.nodeType === Node.ELEMENT_NODE) {
      if (!node.hasAttributes()) return;
      const names = node.getAttributeNames();
      for (let i = 0, len = names.length; i < len; i++) {
        // srcset-family attributes hold many variants of one image; the
        // structural scan already tracked the best candidate
        const name = names[i];
        if (name.includes('srcset')) continue;
        const val = node.getAttribute(name);
        if (val && HTTP_HINT_RE.test(val)) {
          let match;
          IMAGE_URL_RE.lastIndex = 0;
          while ((match = IMAGE_URL_RE.exec(val)) !== null) {
            let url = match[0];
            if (url.includes('\\')) url = url.replace(/\\/g, '');
            trackImage(url);
          }
        }
      }
    }
  }

  // Open Graph / Twitter video metadata. The URL these tags carry is only
  // sometimes media: when the sibling type tag says text/html — YouTube, Vimeo
  // and most embeds — og:video is a *player page*, and downloading it drops an
  // HTML document in the user's Downloads folder under a video-looking name.
  // So a declared type is believed only when it is a real video/* type, and an
  // absent type is treated as untrusted and falls back to the extension check.
  // That also keeps HLS/DASH manifests out, which browser.downloads cannot
  // fetch as a single file (RFC #263).
  const VIDEO_META_SELECTOR = 'meta[property="og:video"], meta[property="og:video:url"], meta[property="og:video:secure_url"], meta[name="twitter:player:stream"]';
  // A Map, not an object literal: the keys are compared against page-controlled
  // attributes, and Map.get() cannot be answered by Object.prototype.
  const VIDEO_META_TYPE_SELECTORS = new Map([
    // og:video:type describes the whole og:video family — there is no
    // og:video:secure_url:type in the Open Graph vocabulary.
    ['og:video', 'meta[property="og:video:type"]'],
    ['og:video:url', 'meta[property="og:video:type"]'],
    ['og:video:secure_url', 'meta[property="og:video:type"]'],
    ['twitter:player:stream', 'meta[name="twitter:player:stream:content_type"]'],
  ]);

  // The media URL a video <meta> carries, or null when it is not one of ours
  // or does not survive the type guard.
  function videoUrlFromMeta(el) {
    const typeSelector = VIDEO_META_TYPE_SELECTORS.get(el.getAttribute('property'))
      || VIDEO_META_TYPE_SELECTORS.get(el.getAttribute('name'));
    if (!typeSelector) return null;
    const url = resolveUrl(el.getAttribute('content'));
    if (!url || url.startsWith('data:')) return null;
    // Looked up at decision time rather than cached during the initial scan:
    // on the MutationObserver path the type tag may not have been inserted yet
    // when this element arrives. Scoped to the parent, so the answer comes from
    // the same <head> the tag lives in; no type found means untrusted, which is
    // the safe direction.
    const typeMeta = el.parentElement ? el.parentElement.querySelector(typeSelector) : null;
    const type = typeMeta && typeMeta.getAttribute('content');
    if (type) return /^video\//i.test(type.trim()) ? url : null;
    return isVideoUrl(url) ? url : null;
  }

  function collectVideos(trackVideo) {
    // <meta> Open Graph / Twitter video metadata (RFC #263)
    document.querySelectorAll(VIDEO_META_SELECTOR).forEach((el) => {
      const url = videoUrlFromMeta(el);
      if (url) trackVideo(url);
    });

    // <video src> and lazy loaded variants
    document.querySelectorAll('video[src], video[data-src], video[data-lazy-src], video[data-original]').forEach((video) => {
      MEDIA_SRC_ATTRS.forEach(attr => {
        const val = video.getAttribute(attr);
        if (val) trackVideo(val);
      });
    });
    // <video><source src> and lazy loaded variants
    document.querySelectorAll('video source[src], video source[data-src], video source[data-lazy-src], video source[data-original]').forEach((source) => {
      MEDIA_SRC_ATTRS.forEach(attr => {
        const val = source.getAttribute(attr);
        if (val) trackVideo(val);
      });
    });
  }

  // Inline <svg> elements have no URL — serialize them into data: URLs on
  // demand. Only runs when the popup connects (never during ambient
  // discovery) so pages that are never snagged pay nothing.
  function collectInlineSvgs() {
    const items = [];
    document.querySelectorAll('svg').forEach((svg) => {
      if (svg.ownerSVGElement) return; // nested <svg> — captured via its root
      const rect = svg.getBoundingClientRect();
      if (rect.width < MIN_IMAGE_SIZE || rect.height < MIN_IMAGE_SIZE) return;
      let markup;
      try {
        markup = new XMLSerializer().serializeToString(svg);
      } catch {
        return;
      }
      if (!markup || markup.length > MAX_INLINE_SVG_CHARS) return;
      // stage 1: <use> refs serialize empty. Checked on the serialized markup, not
      // via querySelector('use') — the HTML parser keeps a foreign-content prefix in
      // the local name, so `<foo:use>` parses to localName "foo:use" and no CSS type
      // selector matches it. Prefix charset is "anything but > , whitespace, colon"
      // because XML names admit `.` and `_` too. Runs after the length cap.
      if (/<(?:[^>\s:]+:)?use\b/i.test(markup)) return;
      items.push({
        url: SVG_DATA_PREFIX + encodeURIComponent(markup),
        type: 'image',
        width: Math.round(rect.width),
        height: Math.round(rect.height),
        derived: true
      });
    });
    return items;
  }

  // <template> content extraction
  // Evaluated on popup connect because getComputedStyle does not apply to disconnected
  // template contents. We explicitly query the DocumentFragment and parse inline styles.
  function collectTemplateMedia() {
    const imageUrls = new Set();
    const videoUrls = new Set();

    const trackImage = (url) => trackImageUrl(url, imageUrls);

    function processTemplate(template) {
      if (!template.content) return;

      template.content.querySelectorAll('*').forEach((el) => {
        extractUrlsFromElement(el, imageUrls, videoUrls);

        // getComputedStyle returns empty on disconnected elements, so manually extract
        // inline background/mask styles.
        if (el.style) {
          const props = [
            el.style.backgroundImage,
            el.style.maskImage,
            el.style.webkitMaskImage,
            el.style.content
          ];
          for (const bg of props) {
            if (bg && bg !== 'none' && bg !== 'normal') {
              for (const raw of extractBgImageUrls(bg)) {
                trackImageUrl(raw, imageUrls);
              }
            }
          }
        }
      });

      // The TreeWalker in the live document does not traverse into template.content.
      const walker = document.createTreeWalker(
        template.content,
        NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT,
        REGEX_SWEEP_FILTER
      );

      let node;
      while ((node = walker.nextNode())) {
        extractRegexUrls(node, trackImage);
      }

      // Process nested templates
      template.content.querySelectorAll('template').forEach(processTemplate);
    }

    document.querySelectorAll('template').forEach(processTemplate);

    return { imageUrls, videoUrls };
  }

  // <noscript> fallback images (RFC #298 stage 1)
  // Evaluated on popup connect because it parses DOM. The HTML parser leaves
  // <noscript> content as raw text; we parse it into an inert Document to run
  // the structural sweep over it safely, without triggering fetches.
  function collectNoscriptImages() {
    const imageUrls = new Set();
    const videoUrls = new Set();
    const parser = new DOMParser();

    document.querySelectorAll('noscript').forEach((noscript) => {
      const text = noscript.textContent;
      if (!text || (!/<img/i.test(text) && !/<picture/i.test(text) && !/<source/i.test(text))) return;

      let doc;
      try {
        doc = parser.parseFromString(text, 'text/html');
      } catch {
        return;
      }

      // Re-use the existing mutation observer handlers on the inert DOM.
      // We don't sweep text nodes (extractRegexUrls) because the TreeWalker
      // in the live document already sweeps the raw <noscript> text node.
      doc.querySelectorAll('*').forEach((el) => {
        handleImg(el, imageUrls);
        handleSrcset(el, imageUrls);
        handleSource(el, imageUrls, videoUrls);
        handlePicture(el, imageUrls);
      });
    });

    return { imageUrls, videoUrls };
  }

  function collectMediaUrls() {
    const imageUrls = new Set();
    const videoUrls = new Set();

    function trackImage(url) {
      trackImageUrl(url, imageUrls);
    }

    function trackVideo(url) {
      const resolved = resolveUrl(url);
      if (resolved && !resolved.startsWith('data:') && !videoUrls.has(resolved)) {
        videoUrls.add(resolved);
      }
    }

    collectImages(trackImage);
    collectVideos(trackVideo);

    return { imageUrls, videoUrls };
  }

  // Size filter — only for images, videos skip this

  function getImageSize(url) {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => resolve({ width: img.naturalWidth, height: img.naturalHeight });
      img.onerror = () => resolve(null);
      img.src = url;
    });
  }

  // Image sizes are read from one pass over document.images, keyed on
  // `currentSrc || src`. Keying on the *rendered* URL is what keeps responsive
  // images honest: a srcset candidate that is not the one being displayed must
  // not inherit the displayed candidate's natural dimensions.
  function buildDomSizeMap() {
    const sizeMap = new Map();
    const imgs = document.images;
    const len = imgs.length;
    for (let i = 0; i < len; i++) {
      const img = imgs[i];
      if (img.naturalWidth > 0 && img.naturalHeight > 0) {
        sizeMap.set(img.currentSrc || img.src, { width: img.naturalWidth, height: img.naturalHeight });
      }
    }
    return sizeMap;
  }

  const pendingNetworkFilter = new Set();

  function passesSizeFilter(size) {
    if (!size) return false;
    // A successful load reporting 0×0 is an SVG without intrinsic size —
    // exempt it like explicit .svg URLs (extension-less SVG CDN endpoints)
    if (size.width === 0 && size.height === 0) return true;
    return size.width >= MIN_IMAGE_SIZE && size.height >= MIN_IMAGE_SIZE;
  }

  async function filterImagesBySize(urls, providedSizeMap) {
    const sizeMap = providedSizeMap || buildDomSizeMap();

    const arr = [...urls];
    const results = new Array(arr.length);
    const pendingIndexes = [];

    for (let index = 0; index < arr.length; index++) {
      const url = arr[index];
      if (isSvgUrl(url)) {
        results[index] = url;
        continue;
      }
      // No getDomImageSize() fallback: sizeMap was just built from
      // document.images keyed on `currentSrc || src`, and getDomImageSize
      // matches a strict subset of that (same element set, but it also
      // requires the literal src *attribute* to equal the resolved URL).
      // A miss here is a miss there too — the querySelector only cost time.
      const domSize = sizeMap.get(url);
      if (domSize) {
        results[index] = passesSizeFilter(domSize) ? url : null;
        continue;
      }
      // Lazy network fetch: if popup is closed, delay the expensive new Image() call
      if (!popupPort) {
        if (pendingNetworkFilter.size < MAX_TRACKED_MEDIA) pendingNetworkFilter.add(url);
        results[index] = null;
        continue;
      }
      pendingIndexes.push(index);
    }

    // Shared cursor: `pendingPos++` is atomic under JS's single-threaded model,
    // so N workers can pull from one queue without a lock. Results are written
    // back by index, never appended, so output order matches input order even
    // though probes settle out of order.
    let pendingPos = 0;

    async function worker() {
      while (pendingPos < pendingIndexes.length) {
        const index = pendingIndexes[pendingPos++];
        const url = arr[index];
        const size = await getImageSize(url);
        // Record the measurement so callers can read dimensions back off the
        // map. Probed URLs are absent from document.images by definition, so
        // without this they reach the popup as 0×0 and lose their size label.
        if (size) sizeMap.set(url, size);
        results[index] = passesSizeFilter(size) ? url : null;
      }
    }

    const workers = [];
    for (let w = 0; w < SIZE_PROBE_POOL_SIZE && w < pendingIndexes.length; w++) {
      workers.push(worker());
    }
    if (workers.length > 0) {
      await Promise.all(workers);
    }

    return results.filter(Boolean);
  }

  // Persistent store management

  function notifyPopup(items) {
    if (popupPort && items.length > 0) {
      popupPort.postMessage({ action: 'new_images', images: items });
    }
  }

  async function addNewUrls(urls, type) {
    if (discoveredMedia.size >= MAX_TRACKED_MEDIA) return;
    const unknown = [...urls].filter((url) => !discoveredMedia.has(url));
    if (unknown.length === 0) return;

    const sizeMap = type === 'image' ? buildDomSizeMap() : null;

    let accepted;
    if (type === 'video') {
      // Videos skip size filtering — can't measure with new Image()
      accepted = unknown;
    } else {
      accepted = await filterImagesBySize(new Set(unknown), sizeMap);
    }

    const items = accepted.map((url) => {
      const size = type === 'image' ? sizeMap.get(url) : null;
      return { url, type, width: size?.width || 0, height: size?.height || 0 };
    });

    const added = [];
    for (const item of items) {
      // Re-checked per item: `urls` can carry more than the headroom the
      // entry guard saw, and the await above means another call may have
      // filled the store in between.
      if (discoveredMedia.size >= MAX_TRACKED_MEDIA) break;
      if (!discoveredMedia.has(item.url)) {
        discoveredMedia.set(item.url, item);
        added.push(item);
      }
    }
    notifyPopup(added);
  }

  // Scan a single element for media URLs (used by MutationObserver)

  function handleImg(el, imageSet) {
    if (isImgLike(el)) {
      // With a srcset present, src is just another variant of the same image
      const hasSet = el.hasAttribute('srcset') || el.hasAttribute('data-srcset') || el.parentElement?.tagName === 'PICTURE';
      let realSet = false;
      if (hasSet) {
        if (el.parentElement?.tagName === 'PICTURE') {
          const pic = el.parentElement;
          for (const source of pic.querySelectorAll('source')) {
            let sourceUsable = false;
            for (const attr of SOURCE_SRCSET_ATTRS) {
              const best = pickBestFromSrcset(source.getAttribute(attr));
              if (best && isRealMediaUrl(best)) { sourceUsable = true; break; }
            }
            if (!sourceUsable) {
              for (const attr of SOURCE_URL_ATTRS) {
                const val = source.getAttribute(attr);
                if (val && isRealMediaUrl(val)) { sourceUsable = true; break; }
              }
            }
            if (sourceUsable) { realSet = true; break; }
          }
        }
        if (!realSet) {
          for (const attr of SOURCE_SRCSET_ATTRS) {
            const val = pickBestFromSrcset(el.getAttribute(attr));
            if (val && isRealMediaUrl(val)) {
              realSet = true;
              break;
            }
          }
        }
      }
      const attrs = ['src', 'data-src', 'data-lazy-src', 'data-original'];
      for (const attr of attrs) {
        let val;
        // `.src` is the resolved IDL form, already resolved against the page's
        // <base href>, so live nodes keep it. Nodes parsed out of a <noscript>
        // text node live in an inert document whose base is about:blank, where
        // `.src` is useless; there we read the raw attribute and let resolveUrl
        // apply the live page's base (document.baseURI).
        if (attr === 'src') {
          if (hasSet && realSet) val = null;
          else val = el.ownerDocument === document ? el.src : el.getAttribute('src');
        }
        else val = el.hasAttribute(attr) ? el.getAttribute(attr) : null;
        if (val) {
          trackImageUrl(val, imageSet);
        }
      }
    }
  }

  function handleSrcset(el, imageSet) {
    if (el.hasAttributes && el.hasAttributes()) {
      // Picture sources are format alternatives handled by handleSource
      if (el.tagName === 'SOURCE' && el.parentElement?.tagName === 'PICTURE') return;
      const attrs = ['srcset', 'data-srcset', 'data-bgset', 'imagesrcset'];
      for (const attr of attrs) {
        const raw = pickBestFromSrcset(el.getAttribute(attr));
        if (raw) {
          trackImageUrl(raw, imageSet);
        }
      }
    }
  }

  function handleVideo(el, imageSet, videoSet) {
    if (el.tagName === 'VIDEO') {
      MEDIA_SRC_ATTRS.forEach(attr => {
        const val = el.getAttribute(attr);
        if (val) {
          const url = resolveUrl(val);
          if (url && !url.startsWith('data:')) videoSet.add(url);
        }
      });
      POSTER_ATTRS.forEach(attr => {
        const val = el.getAttribute(attr);
        if (val) {
          trackImageUrl(val, imageSet);
        }
      });
    }
  }

  function handleSource(el, imageSet, videoSet) {
    if (el.tagName === 'SOURCE') {
      if (el.parentElement?.tagName === 'VIDEO') {
        MEDIA_SRC_ATTRS.forEach(attr => {
          const val = el.getAttribute(attr);
          if (val) {
            const url = resolveUrl(val);
            if (url && !url.startsWith('data:')) videoSet.add(url);
          }
        });
      } else if (el.parentElement?.tagName === 'PICTURE') {
        // Handled per-picture in extractUrlsFromElement
      }
    }
  }

  function processBgImageQueue(deadline) {
    const imageUrls = new Set();
    // The setTimeout fallback (no requestIdleCallback) calls this with no
    // deadline, and a constant budget would make `timeRemaining() > 0` always
    // true — the yield loop would drain the whole queue in one synchronous go.
    // Bound the fallback to a 50ms slice of wall clock instead.
    const start = performance.now();
    const timeRemaining = deadline && typeof deadline.timeRemaining === 'function'
      ? () => deadline.timeRemaining()
      : () => Math.max(0, 50 - (performance.now() - start));

    for (const el of pendingBackgroundCheckQueue) {
      if (timeRemaining() <= 0) break;
      pendingBackgroundCheckQueue.delete(el);
      try {
        for (const raw of getCssMediaUrls(el)) {
          const url = resolveUrl(raw);
          if (url && isImageUrl(url) && !url.startsWith('data:')) imageUrls.add(url);
        }
      } catch {
        // Element may not be connected to DOM yet
      }
    }

    if (imageUrls.size > 0) addNewUrls(imageUrls, 'image');

    if (pendingBackgroundCheckQueue.size > 0) {
      if (typeof requestIdleCallback !== 'undefined') {
        requestIdleCallback(processBgImageQueue);
      } else {
        setTimeout(processBgImageQueue, 1);
      }
    } else {
      isBgCheckScheduled = false;
    }
  }

  function handleMeta(el, imageSet, videoSet) {
    if (el.tagName === 'META') {
      const prop = el.getAttribute('property');
      const name = el.getAttribute('name');
      const itemprop = el.getAttribute('itemprop');
      if (prop === 'og:image' || prop === 'og:image:secure_url' || name === 'twitter:image' || name === 'twitter:image:src' || itemprop === 'image') {
        trackImageUrl(el.getAttribute('content'), imageSet);
      } else if (videoSet) {
        const videoUrl = videoUrlFromMeta(el);
        if (videoUrl) videoSet.add(videoUrl);
      }
    } else if (el.tagName === 'LINK') {
      const rel = el.getAttribute('rel');
      const asAttr = el.getAttribute('as');
      const itemprop = el.getAttribute('itemprop');
      // <link rel=preload as=image imagesrcset="..."> — the responsive preload
      // form. `href` is only the fallback for browsers that ignore imagesrcset,
      // so when a candidate resolves we take it and skip href, the same way
      // <picture> sources and <img srcset> avoid emitting the fallback twice.
      // "Resolves" is the operative word: a candidate that is only an inline
      // data: LQIP puts nothing in the set, so it must fall through to href
      // rather than swallow it.
      if (rel === 'preload' && asAttr === 'image') {
        const best = pickBestFromSrcset(el.getAttribute('imagesrcset'));
        if (isRealMediaUrl(best)) {
          trackImageUrl(best, imageSet);
          return;
        }
      }
      if ((rel === 'preload' && asAttr === 'image') || rel === 'icon' || rel === 'apple-touch-icon' || rel === 'shortcut icon' || rel === 'image_src' || rel === 'mask-icon' || itemprop === 'image') {
        // Outside preload, `href` is the icon the page actually renders, not a
        // fallback — so an imagesrcset candidate is tracked *in addition to* it,
        // never instead of it. trackImageUrl drops falsy and data: input itself.
        if (!(rel === 'preload' && asAttr === 'image')) {
          trackImageUrl(pickBestFromSrcset(el.getAttribute('imagesrcset')), imageSet);
        }
        trackImageUrl(el.getAttribute('href'), imageSet);
      }
    }
  }

  function handleEmbed(el, imageSet) {
    const tag = el.tagName;
    if (tag !== 'OBJECT' && tag !== 'EMBED' && tag !== 'IFRAME') return;
    const raw = tag === 'OBJECT' ? el.getAttribute('data') : el.getAttribute('src');
    const url = resolveUrl(raw);
    if (url && isImageUrl(url) && !url.startsWith('data:')) trackImageUrl(url, imageSet);
  }

  function handleBackgroundImage(el, imageSet) {
    // Fast path: skip elements with no styling hints to avoid expensive getComputedStyle calls
    if (el.hasAttribute('class') || el.id || el.getAttribute('style')) {
      pendingBackgroundCheckQueue.add(el);
      if (!isBgCheckScheduled) {
        isBgCheckScheduled = true;
        if (typeof requestIdleCallback !== 'undefined') {
          requestIdleCallback(processBgImageQueue);
        } else {
          setTimeout(processBgImageQueue, 1);
        }
      }
    }
  }

  function handlePicture(el, imageSet) {
    if (el.tagName === 'PICTURE') {
      const img = el.querySelector('img');
      if (img && img.currentSrc) {
        const url = resolveUrl(img.currentSrc);
        if (url && !url.startsWith('data:')) {
          trackImageUrl(img.currentSrc, imageSet);
          return;
        }
      }
      // One closure per <picture>, not per <source> — handlePicture runs on the
      // MutationObserver path.
      const track = (raw) => trackImageUrl(raw, imageSet);
      for (const source of el.querySelectorAll('source')) {
        if (collectSourceVariants(source, track)) return;
      }
    }
  }

  function handleSvgImage(el, imageSet) {
    if (el.tagName === 'image' || el.tagName === 'IMAGE') {
      const raw = el.getAttribute('href') || el.getAttribute('xlink:href');
      trackImageUrl(raw, imageSet);
    }
  }

  function handleAnchor(el, imageSet) {
    if (el.tagName === 'A' || el.tagName === 'AREA') {
      const raw = el.getAttribute('href');
      const url = resolveUrl(raw);
      if (url && isImageUrl(url) && !url.startsWith('data:')) {
        trackImageUrl(raw, imageSet);
      }
    }
  }

  function handleDataBg(el, imageSet) {
    if (el.hasAttributes && el.hasAttributes()) {
      for (const attr of DATA_BG_ATTRS) {
        if (el.hasAttribute(attr)) {
          const bg = el.getAttribute(attr);
          if (bg) {
            if (bg.includes('url(') || bg.includes('image-set(')) {
              for (const raw of extractBgImageUrls(bg)) {
                trackImageUrl(raw, imageSet);
              }
            } else {
              const url = resolveUrl(bg.trim());
              if (isImageUrl(url) && !url.startsWith('data:')) imageSet.add(url);
            }
          }
        }
      }
    }
  }

  function extractUrlsFromElement(el, imageSet, videoSet) {
    handleImg(el, imageSet);
    handleSrcset(el, imageSet);
    handleVideo(el, imageSet, videoSet);
    handleSource(el, imageSet, videoSet);
    handleBackgroundImage(el, imageSet);
    handleDataBg(el, imageSet);
    handleMeta(el, imageSet, videoSet);
    handleEmbed(el, imageSet);
    handlePicture(el, imageSet);
    handleSvgImage(el, imageSet);
    handleAnchor(el, imageSet);
  }

  // Observers — continuous media tracking

  function setupMutationObserver() {
    const observer = new MutationObserver((mutations) => {
      const imageUrls = new Set();
      const videoUrls = new Set();
      // Hoisted out of the node loops: one closure per batch, not per node
      const trackSweptImage = (url) => {
        trackImageUrl(url, imageUrls);
      };
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          if (node.nodeType === Node.ELEMENT_NODE) {
            extractUrlsFromElement(node, imageUrls, videoUrls);
          }

          if (node.nodeType === Node.ELEMENT_NODE || node.nodeType === Node.TEXT_NODE) {
            extractRegexUrls(node, trackSweptImage);
          }

          if (node.nodeType === Node.ELEMENT_NODE) {
            if (REGEX_SWEEP_FILTER.acceptNode(node) === NodeFilter.FILTER_REJECT) continue;
            const walker = document.createTreeWalker(
              node,
              NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT,
              REGEX_SWEEP_FILTER
            );

            let el;
            while ((el = walker.nextNode())) {
              extractRegexUrls(el, trackSweptImage);
              if (el.nodeType !== Node.ELEMENT_NODE) continue;
              const tag = el.tagName;
              if (
                TAG_SET.has(tag) ||
                (el.hasAttributes && el.hasAttributes() && (
                  el.hasAttribute('srcset') || el.hasAttribute('data-srcset') || el.hasAttribute('data-bgset') || el.hasAttribute('imagesrcset') ||
                  el.hasAttribute('data-src') || el.hasAttribute('data-lazy-src') || el.hasAttribute('data-original') ||
                  el.hasAttribute('data-bg') || el.hasAttribute('data-bg-src') || el.hasAttribute('data-background') ||
                  el.hasAttribute('data-background-image') ||
                  (el.hasAttribute('style') && (el.getAttribute('style').toLowerCase().includes('background') || el.getAttribute('style').toLowerCase().includes('mask')))
                ))
              ) {
                extractUrlsFromElement(el, imageUrls, videoUrls);
              }
            }
          }
        }
      }
      if (imageUrls.size > 0) addNewUrls(imageUrls, 'image');
      if (videoUrls.size > 0) addNewUrls(videoUrls, 'video');
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  function setupPerformanceObserver() {
    try {
      const observer = new PerformanceObserver((list) => {
        const imageUrls = new Set();
        const videoUrls = new Set();
        // URLs currently rendered by srcset-bearing imgs: the structural scan
        // already tracked their best candidate — re-adding the rendered
        // variant would duplicate the same image under a second URL
        let renderedVariants = null;
        const getRenderedVariants = () => {
          if (renderedVariants) return renderedVariants;
          renderedVariants = new Set();
          const imgs = document.images;
          for (let i = 0, len = imgs.length; i < len; i++) {
            const im = imgs[i];
            if (im.currentSrc && (im.hasAttribute('srcset') || im.hasAttribute('data-srcset') || im.parentElement?.tagName === 'PICTURE')) {
              renderedVariants.add(im.currentSrc);
            }
          }
          return renderedVariants;
        };
        for (const entry of list.getEntries()) {
          const url = resolveUrl(entry.name);
          if (!url || url.startsWith('data:') || discoveredMedia.has(url)) continue;

          if (isVideoUrl(url) || entry.initiatorType === 'video') {
            videoUrls.add(url);
          } else if (IMAGE_EXT_RE.test(entry.name) || entry.initiatorType === 'img') {
            if (entry.initiatorType === 'img' && getRenderedVariants().has(url)) continue;
            imageUrls.add(url);
          }
        }
        if (imageUrls.size > 0) addNewUrls(imageUrls, 'image');
        if (videoUrls.size > 0) addNewUrls(videoUrls, 'video');
      });
      observer.observe({ type: 'resource', buffered: true });
    } catch {
      // PerformanceObserver not supported
    }
  }

  // Popup port connection
  if (typeof browser !== 'undefined' && browser.runtime) {
    browser.runtime.onConnect.addListener((port) => {
      if (port.name !== 'imgsnag-popup') return;
      popupPort = port;

      // Capture inline SVGs now so they ride along in the init payload
      for (const item of collectInlineSvgs()) {
        if (discoveredMedia.size >= MAX_TRACKED_MEDIA) break;
        if (!discoveredMedia.has(item.url)) discoveredMedia.set(item.url, item);
      }

      // Capture <noscript> fallback images (RFC #298 stage 1)
      const noscriptMedia = collectNoscriptImages();
      if (noscriptMedia.imageUrls.size > 0) addNewUrls(noscriptMedia.imageUrls, 'image');
      if (noscriptMedia.videoUrls.size > 0) addNewUrls(noscriptMedia.videoUrls, 'video');

      // Capture <template> media
      const templateMedia = collectTemplateMedia();
      if (templateMedia.imageUrls.size > 0) addNewUrls(templateMedia.imageUrls, 'image');
      if (templateMedia.videoUrls.size > 0) addNewUrls(templateMedia.videoUrls, 'video');

      port.postMessage({ action: 'init', images: [...discoveredMedia.values()] });

      // Flush the background image check queue synchronously so the grid is complete
      if (pendingBackgroundCheckQueue.size > 0) {
        const imageUrls = new Set();
        for (const el of pendingBackgroundCheckQueue) {
          pendingBackgroundCheckQueue.delete(el);
          try {
            for (const raw of getCssMediaUrls(el)) {
              const url = resolveUrl(raw);
              if (url && isImageUrl(url) && !url.startsWith('data:')) imageUrls.add(url);
            }
          } catch {
            // Element may not be connected to DOM yet
          }
        }
        if (imageUrls.size > 0) addNewUrls(imageUrls, 'image');
      }

      // Process any images that were lazily delayed until the popup connected
      if (pendingNetworkFilter.size > 0) {
        const urls = new Set(pendingNetworkFilter);
        pendingNetworkFilter.clear();
        addNewUrls(urls, 'image');
      }

      port.onDisconnect.addListener(() => {
        popupPort = null;
      });
    });
  }

  // Initial scan

  async function initialScan() {
    const { imageUrls, videoUrls } = collectMediaUrls();
    await addNewUrls(imageUrls, 'image');
    await addNewUrls(videoUrls, 'video');
    setupMutationObserver();
    setupPerformanceObserver();
  }

  if (typeof browser !== 'undefined' && browser.runtime) {
    initialScan();
  }

  // Alt+Click — downloads the image(s) stacked under the cursor

  function getTargetUrlsForElement(el) {
    const urls = [];

    if (isImgLike(el)) {
      let realSet = false;
      if (el.parentElement?.tagName === 'PICTURE') {
        const pic = el.parentElement;
        for (const source of pic.querySelectorAll('source')) {
          for (const attr of SOURCE_SRCSET_ATTRS) {
            const best = pickBestFromSrcset(source.getAttribute(attr));
            if (best && isRealMediaUrl(best)) { urls.push(resolveUrl(best)); realSet = true; break; }
          }
          if (!realSet) {
            for (const attr of SOURCE_URL_ATTRS) {
              const val = source.getAttribute(attr);
              if (val && isRealMediaUrl(val)) { urls.push(resolveUrl(val)); realSet = true; break; }
            }
          }
          if (realSet) break;
        }
      }

      if (!realSet && (el.hasAttribute('srcset') || el.hasAttribute('data-srcset') || el.hasAttribute('data-bgset') || el.hasAttribute('imagesrcset'))) {
        for (const attr of ['srcset', 'data-srcset', 'data-bgset', 'imagesrcset']) {
          const val = pickBestFromSrcset(el.getAttribute(attr));
          if (val && isRealMediaUrl(val)) {
            urls.push(resolveUrl(val));
            realSet = true;
            break;
          }
        }
      }

      if (realSet) return urls;

      if (el.currentSrc) {
        const url = resolveUrl(el.currentSrc);
        if (url && !url.startsWith('data:')) {
          urls.push(url);
          return urls;
        }
      }

      for (const attr of MEDIA_SRC_ATTRS) {
        let val;
        if (attr === 'src') val = el.src;
        else val = el.hasAttribute(attr) ? el.getAttribute(attr) : null;
        if (val) {
          const url = resolveUrl(val);
          if (url && !url.startsWith('data:')) {
            urls.push(url);
            return urls;
          }
        }
      }
      return urls;
    }

    if (el.tagName === 'VIDEO') {
      for (const attr of MEDIA_SRC_ATTRS) {
        const val = el.getAttribute(attr);
        if (val) {
          const url = resolveUrl(val);
          if (url && !url.startsWith('data:')) {
            urls.push(url);
            return urls;
          }
        }
      }
      for (const source of el.querySelectorAll('source')) {
        for (const attr of MEDIA_SRC_ATTRS) {
          const val = source.getAttribute(attr);
          if (val) {
            const url = resolveUrl(val);
            if (url && !url.startsWith('data:')) {
              urls.push(url);
              return urls;
            }
          }
        }
      }
      return urls;
    }

    for (const raw of getCssMediaUrls(el)) {
      const url = resolveUrl(raw);
      if (url && isImageUrl(url) && !url.startsWith('data:')) urls.push(url);
    }

    if (el.tagName === 'A' || el.tagName === 'AREA') {
      const url = resolveUrl(el.getAttribute('href'));
      if (url && isImageUrl(url) && !url.startsWith('data:')) urls.push(url);
    }

    return urls;
  }

  function downloadImagesAtPoint(e) {
    const elements = document.elementsFromPoint(e.clientX, e.clientY);
    const downloadedUrls = new Set();
    let didDownload = false;

    for (const el of elements) {
      const targetUrls = getTargetUrlsForElement(el);
      for (const url of targetUrls) {
        if (!downloadedUrls.has(url)) {
          downloadedUrls.add(url);
          sendToBackground({ action: 'download_image', url });
          didDownload = true;
        }
      }
    }

    if (didDownload) {
      e.preventDefault();
      e.stopPropagation();
    }
  }

  document.addEventListener('click', (e) => {
    // Warden: Prevent hostile pages from synthesizing events to force downloads
    if (!e.isTrusted) return;
    if (e.altKey) {
      downloadImagesAtPoint(e);
    }
  });

  // Drag-to-save (can be disabled in options)
  document.addEventListener('dragend', (e) => {
    // Warden: Prevent hostile pages from synthesizing events to force downloads
    if (!e.isTrusted) return;
    if (isImgLike(e.target) && !isDragDisabled) {
      const urls = getTargetUrlsForElement(e.target);
      for (const url of urls) {
        sendToBackground({ action: 'download_image', url });
        break; // Only trigger one download
      }
    }
  });

  function syncDragPreference() {
    if (typeof browser !== 'undefined' && browser.storage) {
      browser.storage.sync.get({ disableDrag: false }).then((items) => {
        isDragDisabled = items.disableDrag;
      });
    }
  }

  syncDragPreference();
  browser.storage.onChanged.addListener(() => syncDragPreference());
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { handleImg, handleSrcset, trackImageUrl, buildDomSizeMap, getCssMediaUrls, extractBgImageUrls, resolveUrl, isVideoUrl, isImageUrl, isSvgUrl, parseSrcset, pickBestFromSrcset, collectInlineSvgs, collectNoscriptImages, collectTemplateMedia, handleEmbed, passesSizeFilter, handleMeta, collectMediaUrls, handleSource, handlePicture, handleSvgImage, handleAnchor, handleDataBg, extractRegexUrls, handleVideo, filterImagesBySize, SIZE_PROBE_POOL_SIZE, REGEX_SWEEP_FILTER, BG_IMAGE_SELECTORS, addNewUrls, MAX_TRACKED_MEDIA, TAG_SET, processBgImageQueue, getTargetUrlsForElement };
  }
})();
